#include <stdio.h>

int main()
{
int a = 1;
			double bb = 22.22;
}

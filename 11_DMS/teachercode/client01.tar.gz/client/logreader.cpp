// 实现日志读取器类
#include "logreader.h"
// 构造器
LogReader::LogReader (const string& logFile,
	const string& loginsFile) :
	m_logFile (logFile),
	m_loginsFile (loginsFile) {}
// 读取日志
list<MLogRec>& LogReader::readLog (void)
	throw (ReadException) {
	cout << "读取日志开始..." << endl;
	try {
		// 备份日志文件
		backup ();
		// 读取登入文件
		readLoginsFile ();
		// 读取备份文件
		readBackupFile ();
		// 匹配登入登出
		match ();
		// 保存登入文件
		saveLoginsFile ();
	}
	catch (BackupException& ex) {
		throw ReadException ("备份错误");
	}
	catch (ReadException& ex) {
		throw ReadException ("读取错误");
	}
	catch (SaveException& ex) {
		throw ReadException ("保存错误");
	}
	catch (...) {
		throw ReadException ("未知错误");
	}
	cout << "读取日志完成。" << endl;
	return m_logs;
}
// 备份日志文件
void LogReader::backup (void)
	throw (BackupException) {
	cout << "备份文件开始..." << endl;

	cout << "备份文件完成。" << endl;
}
// 读取登入文件
void LogReader::readLoginsFile (void)
	throw (ReadException) {
	cout << "读取登入文件开始..." << endl;

	cout << "读取登入文件完成。" << endl;
}
// 读取备份文件
void LogReader::readBackupFile (void)
	throw (ReadException) {
	cout << "读取备份文件开始..." << endl;

	cout << "读取备份文件完成。" << endl;
}
// 匹配登入登出
void LogReader::match (void) {
	cout << "匹配登入登出开始..." << endl;

	cout << "匹配登入登出完成。" << endl;
}
// 保存登入文件
void LogReader::saveLoginsFile (void)
	throw (SaveException) {
	cout << "保存登入文件开始..." << endl;

	cout << "保存登入文件完成。" << endl;
}

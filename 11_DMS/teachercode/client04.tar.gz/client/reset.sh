#!/bin/bash
rm -rf ./wtmpx.2013*
rm -rf ./*.dat
cp ../wtmpx ./
exit 0

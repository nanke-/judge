#!/bin/bash
cd /home/tarena/dms/client
./client
exit 0

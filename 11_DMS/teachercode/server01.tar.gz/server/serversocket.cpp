// 实现服务器套接字类
#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
using namespace std;
#include "serversocket.h"
#include "clientthread.h"
// 构造器
ServerSocket::ServerSocket (const string& ip,
	short port) throw (SocketException) {
	cout << "初始化服务器开始..." << endl;

	cout << "初始化服务器完成。" << endl;
}
// 等待客户机连接
void ServerSocket::acceptClient (void)
	throw (SocketException) {
	cout << "等待客户机连接..." << endl;
	// 循环阻塞
	for (;;) {
		int connfd = 0;
		// 创建一个客户线程为其提供服务
		(new ClientThread (connfd))->start ();
		pause ();
	}
}

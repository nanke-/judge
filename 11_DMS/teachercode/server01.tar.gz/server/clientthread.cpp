// 实现客户线程类
#include <iostream>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
using namespace std;
#include "clientthread.h"
#include "logbuffer.h"
// 构造器
ClientThread::ClientThread (int connfd) :
	m_connfd (connfd) {}
// 线程处理
void ClientThread::run (void) {
	MLogRec log = {"minwei", "127.0.0.1",
		100, 300, 200};
	for (size_t i = 0; i < 10; ++i) {
		g_logBuffer << log;
	}
	delete this;
}
